"""Re-derive every number and statistic quoted in the manuscript from the tabulated data.

Reads  data/reported/*.csv|json  and checks
  * flow parameters (D_h, u_mean from Re, u_max = 1.5 u_mean),
  * the analytical Poiseuille column of Table 1,
  * the MVNAE column of Table 1 and its summary statistics (mean, RMS, max, count <= 5 %),
  * the confusion-matrix metrics of Fig. 7.
It then redraws Fig. 11 from the table. Error bars are drawn ONLY if a file with real
per-position standard deviations is supplied (--sigma_csv, column `sigma_mm_s`).

Usage: python scripts/05_reproduce_reported_results.py [--sigma_csv my_sigmas.csv]
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))  # make `psv` importable
import argparse, json, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from psv import config as C
from psv.velocity import (poiseuille_velocity, mvnae, error_summary,
                          hydraulic_diameter, reynolds)
from psv.metrics import classification_metrics, plot_confusion

ap = argparse.ArgumentParser()
ap.add_argument("--sigma_csv", default=None)
args = ap.parse_args()
out = "results/reported_reproduction"
os.makedirs(out, exist_ok=True)

# ---------------- flow parameters ----------------
Dh = hydraulic_diameter()
Re = reynolds(C.U_MEAN_MMS, Dh)
checks = {
    "D_h_mm (2WH/(W+H))": round(Dh, 3),
    "Re from u_mean=1.575 mm/s": round(Re, 2),
    "u_max = 1.5*u_mean (mm/s)": round(C.U_MAX_MMS, 4),
    "aspect ratio W/H": round(C.W_MM / C.H_MM, 2),
    "FOV from 0.265 um/px: width x height (um)": [round(1312 * 0.265, 1), round(1082 * 0.265, 1)],
    "particle image diameter (px) = 20 um / 0.265": round(20 / 0.265, 1),
    "streak length at u_max over 45 ms (px)": round(C.U_MAX_MMS * 1e-3 * 0.045 / 0.265e-6, 1),
}

# ---------------- Table 1 ----------------
t = pd.read_csv("data/reported/table1_velocity_profile.csv")
t["u_poiseuille_recomputed"] = poiseuille_velocity(t.z_mm, C.H_MM, 2.363).round(3)
t["mvnae_recomputed_umax2.363"] = mvnae(t.u_psv_mm_s, t.u_poiseuille_mm_s, 2.363).round(2)
t["mvnae_recomputed_umax2.36"] = mvnae(t.u_psv_mm_s, t.u_poiseuille_mm_s, 2.36).round(2)
t.to_csv(os.path.join(out, "table1_recomputed.csv"), index=False)
s_rep = error_summary(t.mvnae_percent_reported)
s_rec = error_summary(t["mvnae_recomputed_umax2.363"])
summary = {
    "flow_checks": checks,
    "table1_max_abs_diff_poiseuille_column": float(np.abs(t.u_poiseuille_mm_s - t.u_poiseuille_recomputed).max()),
    "table1_max_abs_diff_mvnae_column(u_max=2.363)": float(np.abs(t.mvnae_percent_reported - t["mvnae_recomputed_umax2.363"]).max()),
    "summary_from_reported_column": s_rep,
    "summary_recomputed_from_velocities": s_rec,
    "quoted_in_manuscript": {"mean": 2.64, "rms": 3.19, "max": 7.28, "n_le_5pct": 19},
}

# ---------------- Confusion matrix (Fig. 7) ----------------
cm = json.load(open("data/reported/confusion_matrix_test.json"))["matrix"]
y_true = [0] * 150 + [1] * 150
y_pred = [0] * 150 + [0] * 1 + [1] * 149
m = classification_metrics(y_true, y_pred)
summary["confusion_metrics_recomputed"] = m
plot_confusion(cm, os.path.join(out, "confusion_matrix_reported.png"),
               title="Reported test-set confusion matrix (Fig. 7)")
json.dump(summary, open(os.path.join(out, "reproduction_summary.json"), "w"), indent=2)
print(json.dumps(summary, indent=2))

# ---------------- Fig. 11 ----------------
H, umax = C.H_MM, 2.363
zf = np.linspace(0, H, 300)
fig, (a, b) = plt.subplots(1, 2, figsize=(11, 5))
a.plot(poiseuille_velocity(zf, H, umax), zf, color="#1f3fbf", lw=2, label="Analytical Poiseuille profile")
xerr = None
if args.sigma_csv:
    sig = pd.read_csv(args.sigma_csv)
    xerr = sig["sigma_mm_s"].values
a.errorbar(t.u_psv_mm_s, t.z_mm, xerr=xerr, fmt="o", color="crimson", capsize=3,
           label="PSV measurements (±1σ)" if xerr is not None else "PSV measurements")
a.axhline(H, color="k", lw=2)
a.set_xlabel("Velocity (mm/s)"); a.set_ylabel("Depth position, z (mm)")
a.set_title("(a) Velocity profile: measured vs analytical"); a.legend(loc="lower right"); a.grid(alpha=.3)
a.set_xlim(0, 2.5); a.set_ylim(0, 0.95)
if xerr is None:
    a.text(0.98, 0.97, "no sigma data supplied:\nerror bars omitted", transform=a.transAxes,
           ha="right", va="top", fontsize=8, color="gray")
b.barh(t.z_mm, t.mvnae_percent_reported, height=0.03, color="#9ecae1", edgecolor="#2166ac")
# Summary values as quoted in the manuscript (computed there from UNROUNDED velocities).
# From the 2-decimal table alone the mean is 2.63 to 2.64 and the RMS 3.19 to 3.20.
Q = summary["quoted_in_manuscript"]
b.axvline(Q["mean"], color="crimson", ls="--", label=f"Mean = {Q['mean']:.2f}%")
b.axvline(5, color="gray", ls=":", label="5% threshold")
b.text(5.5, 0.30, f"n = {s_rep['n']}\nMean MVNAE: {Q['mean']:.2f} %\nMax MVNAE: {Q['max']:.2f} %\n"
       f"RMS error: {Q['rms']:.2f} %\n(values as quoted in the paper)", fontsize=9,
       bbox=dict(boxstyle="round", fc="white", ec="gray"))
b.set_xlabel("MVNAE (%)"); b.set_ylabel("Depth position, z (mm)"); b.set_xlim(0, 10); b.set_ylim(0, 0.95)
b.set_title("(b) Point-by-point MVNAE"); b.legend(loc="lower right"); b.grid(alpha=.3, axis="x")
fig.tight_layout(); fig.savefig(os.path.join(out, "fig11_regenerated_from_table1.png"), dpi=170)
print("saved", out)
