"""End-to-end demonstration on UNSEEN synthetic frames (ground truth known).

For each frame: background subtraction -> enhancement -> 85th-percentile threshold ->
contours -> CNN classification -> denoised reconstruction -> streak length, angle and
velocity vectors. Because the synthetic ground truth is known, we also report
  * recovery of true streaks (kept) and rejection of artifact pixels,
  * measured vs true streak length (bias caused by the percentile threshold),
  * a depth-profile comparison in the same MVNAE form used in the paper.
These numbers describe the synthetic demo only. They are not the paper's results.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))  # make `psv` importable
import argparse, json, os
import numpy as np
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from psv.model import build_model
from psv import synthetic as S, preprocessing as P, config as C
from psv.reconstruct import classify_candidates, reconstruct
from psv.velocity import streak_geometry, mvnae, error_summary

ap = argparse.ArgumentParser()
ap.add_argument("--n_frames", type=int, default=20)
ap.add_argument("--seed", type=int, default=2024)
ap.add_argument("--weights", default="models/psv_cnn.weights.h5")
ap.add_argument("--out", default="results/demo_synthetic")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)

bgz = np.load("data/synthetic/background.npz")
B, SD, static = bgz["mean"], bgz["std"], bgz["static"]
model = build_model(); model.load_weights(args.weights)
rng = np.random.default_rng(args.seed)          # frames never seen in training

rows = []           # per retained candidate: measured vs true length
art_removed, art_total, streak_kept, streak_total = 0, 0, 0, 0
example = None
for k in range(args.n_frames):
    frame, truth = S.make_frame(static, rng)
    out = P.run_preprocessing(frame, B, SD)
    cands = out["candidates"]
    pred, prob = classify_candidates(model, cands)
    clean = reconstruct(out["subtracted"], cands, pred)
    truth_mask = np.zeros(frame.shape, bool)
    for m in truth["streak_masks"]:
        truth_mask |= m
    kept_mask = clean > 0
    bright = out["thresholded"] > 0
    art = bright & ~truth_mask                      # surviving non-streak pixels
    art_total += int(art.sum()); art_removed += int((art & ~kept_mask).sum())
    st = bright & truth_mask
    streak_total += int(st.sum()); streak_kept += int((st & kept_mask).sum())
    for c, p in zip(cands, pred):
        if p != 1:
            continue
        hits = [i for i, m in enumerate(truth["streak_masks"]) if (c.mask & m).any()]
        if len(hits) != 1:
            continue
        L, ang, (cx, cy) = streak_geometry(c.mask)
        tp = truth["streak_params"][hits[0]]
        rows.append((k, cx, cy, L, ang, tp["length"], tp["cy"]))
    if k == 0:
        example = (frame, out, cands, pred, clean)

rows = np.array(rows)
Lm, Lt, ycen = rows[:, 3], rows[:, 5], rows[:, 2]
bias = float(np.mean((Lm - Lt) / Lt) * 100)
H = frame.shape[0]
# depth-profile: mean measured vs mean true length in 10 vertical bins, MVNAE-style
bins = np.linspace(0, H, 11)
idx = np.digitize(ycen, bins) - 1
prof_m = np.array([Lm[idx == i].mean() if (idx == i).any() else np.nan for i in range(10)])
prof_t = np.array([Lt[idx == i].mean() if (idx == i).any() else np.nan for i in range(10)])
ok = ~np.isnan(prof_m)
eps = mvnae(prof_m[ok], prof_t[ok], np.nanmax(prof_t))
res = dict(n_frames=args.n_frames, n_retained_single_streak=int(len(rows)),
           artifact_pixel_rejection_pct=round(100 * art_removed / max(art_total, 1), 2),
           true_streak_pixel_retention_pct=round(100 * streak_kept / max(streak_total, 1), 2),
           mean_length_bias_pct=round(bias, 2),
           length_pearson_r=round(float(np.corrcoef(Lm, Lt)[0, 1]), 4),
           depth_profile_mvnae=error_summary(eps),
           note="Synthetic data only. Not the manuscript's experimental results.")
json.dump(res, open(os.path.join(args.out, "end_to_end_metrics.json"), "w"), indent=2)
print(json.dumps(res, indent=2))

# ---- figure A: before / after + vectors ----
frame, out, cands, pred, clean = example
fig, ax = plt.subplots(2, 2, figsize=(13, 9))
ax[0, 0].imshow(frame, cmap="gray"); ax[0, 0].set_title("(a) Raw synthetic frame")
ax[0, 1].imshow(out["thresholded"], cmap="gray")
ax[0, 1].set_title(f"(b) After subtraction, enhancement, {C.THRESHOLD_PERCENTILE:.0f}th-pct threshold\n"
                   f"(threshold = {out['threshold']:.0f}, {len(cands)} candidates)")
ax[1, 0].imshow(clean, cmap="gray"); ax[1, 0].set_title(f"(c) CNN-denoised reconstruction ({int(pred.sum())} retained)")
ax[1, 1].imshow(np.zeros_like(clean), cmap="gray", vmin=0, vmax=1)
for c, p in zip(cands, pred):
    x, y, w, h = c.bbox
    col = "lime" if p == 1 else "red"
    ax[0, 1].add_patch(plt.Rectangle((x, y), w, h, fill=False, ec=col, lw=1))
    if p == 1:
        L, ang, (cx, cy) = streak_geometry(c.mask)
        dx, dy = np.cos(np.radians(ang)) * L / 2, np.sin(np.radians(ang)) * L / 2
        ax[1, 1].arrow(cx - dx, cy - dy, 2 * dx, 2 * dy, color="lime", head_width=6,
                       length_includes_head=True)
ax[1, 1].set_xlim(0, frame.shape[1]); ax[1, 1].set_ylim(frame.shape[0], 0)
ax[1, 1].set_title("(d) Streak vectors (length ~ speed; sign from bulk flow, left to right)")
for a in ax.flat:
    a.set_xticks([]); a.set_yticks([])
fig.suptitle("End-to-end pipeline on an unseen SYNTHETIC frame (green = retained, red = replaced)")
fig.tight_layout(); fig.savefig(os.path.join(args.out, "end_to_end_example.png"), dpi=140)

# ---- figure B: length recovery + profile ----
fig, (a, b) = plt.subplots(1, 2, figsize=(11, 4.6))
a.scatter(Lt, Lm, s=14, alpha=.6); lim = [0, max(Lt.max(), Lm.max()) * 1.05]
a.plot(lim, lim, "k--", lw=1, label="1:1"); a.set_xlim(lim); a.set_ylim(lim)
a.set_xlabel("True streak length (px)"); a.set_ylabel("Measured streak length (px)")
a.set_title(f"(a) Length recovery, mean bias {bias:.1f} %"); a.legend(); a.grid(alpha=.3)
zc = (bins[:-1] + bins[1:]) / 2 / H
b.plot(prof_t[ok], zc[ok], "o-", label="True mean length"); b.plot(prof_m[ok], zc[ok], "s--", label="Measured mean length")
b.set_xlabel("Streak length (px)"); b.set_ylabel("y / H")
b.set_title(f"(b) Profile across frame height, mean MVNAE {res['depth_profile_mvnae']['mean']:.2f} %")
b.legend(); b.grid(alpha=.3)
fig.tight_layout(); fig.savefig(os.path.join(args.out, "end_to_end_length_recovery.png"), dpi=140)
