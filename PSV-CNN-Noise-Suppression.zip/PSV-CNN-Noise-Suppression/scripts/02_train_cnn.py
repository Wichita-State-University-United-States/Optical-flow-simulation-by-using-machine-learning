"""Train the PSV streak classifier and save the learning history.

Usage:  python scripts/02_train_cnn.py --epochs 100          (paper setting)
        python scripts/02_train_cnn.py --epochs 25            (quick demo)
        python scripts/02_train_cnn.py --epochs 25 --resume --stop_after 8
            (run in chunks of 8 epochs; a checkpoint is written after every epoch)

Augmentation is applied to the training subset only. The validation subset is used
to monitor convergence. The test set is NOT touched here (see 03_evaluate_cnn.py).
Outputs: models/psv_cnn.weights.h5, results/demo_synthetic/training_history.csv and
training_history.png. The history plotted is the real logged history of this run.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))  # make `psv` importable
import argparse, csv, json, os, time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tensorflow as tf
from psv.model import build_model
from psv.augment import augment_batch
from psv import config as C

ap = argparse.ArgumentParser()
ap.add_argument("--epochs", type=int, default=C.EPOCHS_PAPER)
ap.add_argument("--data", default="data/synthetic")
ap.add_argument("--batch", type=int, default=C.BATCH_SIZE)
ap.add_argument("--seed", type=int, default=1)
ap.add_argument("--resume", action="store_true", help="continue from models/checkpoint.keras")
ap.add_argument("--stop_after", type=int, default=0, help="stop after this many epochs in this call (0 = run all)")
args = ap.parse_args()
tf.keras.utils.set_random_seed(args.seed)
os.makedirs("models", exist_ok=True)
out_dir = "results/demo_synthetic"
os.makedirs(out_dir, exist_ok=True)


def load(name):
    d = np.load(os.path.join(args.data, name))
    return (d["X"].astype(np.float32) / 255.0)[..., None], d["y"]


Xtr, ytr = load("train.npz")
Xva, yva = load("val.npz")
print(f"train {Xtr.shape} val {Xva.shape}")
CKPT, HIST = "models/checkpoint.keras", "models/history.json"
hist = dict(loss=[], accuracy=[], val_loss=[], val_accuracy=[])
start = 1
if args.resume and os.path.exists(CKPT) and os.path.exists(HIST):
    model = tf.keras.models.load_model(CKPT)
    hist = json.load(open(HIST))
    start = len(hist["loss"]) + 1
    print(f"resuming from epoch {start}")
else:
    model = build_model()
t0, done_this_call = time.time(), 0
for ep in range(start, args.epochs + 1):
    ep_rng = np.random.default_rng(args.seed * 100003 + ep)   # reproducible per-epoch augmentation
    Xa = augment_batch(Xtr, ep_rng)                           # fresh augmentation each epoch
    h = model.fit(Xa, ytr, batch_size=args.batch, epochs=1, shuffle=True,
                  validation_data=(Xva, yva), verbose=0)
    for k in hist:
        hist[k].append(float(h.history[k][0]))
    model.save(CKPT); json.dump(hist, open(HIST, "w"))
    print(f"epoch {ep:3d}/{args.epochs}  loss {hist['loss'][-1]:.4f}  acc {hist['accuracy'][-1]:.3f}  "
          f"val_loss {hist['val_loss'][-1]:.4f}  val_acc {hist['val_accuracy'][-1]:.3f}  "
          f"[{time.time() - t0:.0f}s]", flush=True)
    done_this_call += 1
    if args.stop_after and done_this_call >= args.stop_after and ep < args.epochs:
        print("stopping early for this call; rerun with --resume"); sys.exit(0)
model.save_weights("models/psv_cnn.weights.h5")

with open(os.path.join(out_dir, "training_history.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["epoch", "train_loss", "train_acc", "val_loss", "val_acc"])
    for i in range(args.epochs):
        w.writerow([i + 1, f"{hist['loss'][i]:.5f}", f"{hist['accuracy'][i]:.5f}",
                    f"{hist['val_loss'][i]:.5f}", f"{hist['val_accuracy'][i]:.5f}"])

ep = np.arange(1, args.epochs + 1)
fig, (a, b) = plt.subplots(1, 2, figsize=(10, 4))
a.plot(ep, np.array(hist["accuracy"]) * 100, label="Training accuracy")
a.plot(ep, np.array(hist["val_accuracy"]) * 100, "--", label="Validation accuracy")
a.set_xlabel("Epoch"); a.set_ylabel("Accuracy (%)"); a.set_title("(a) Accuracy"); a.legend(); a.grid(alpha=.3)
b.plot(ep, hist["loss"], label="Training loss")
b.plot(ep, hist["val_loss"], "--", label="Validation loss")
b.set_xlabel("Epoch"); b.set_ylabel("Loss"); b.set_title("(b) Loss"); b.legend(); b.grid(alpha=.3)
fig.suptitle("Learning history on SYNTHETIC demo data (real logged run)")
fig.tight_layout()
fig.savefig(os.path.join(out_dir, "training_history.png"), dpi=150)
print("saved weights and history")
