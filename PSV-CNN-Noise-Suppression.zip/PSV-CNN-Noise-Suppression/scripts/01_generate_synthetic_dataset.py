"""Build a balanced, frame-level-split SYNTHETIC patch dataset.

Mirrors the manuscript protocol (Section 2.3): 600 patches, 300 retained and 300
replaced, 50:50 train/test split performed at the level of the source frames (no
frame contributes to both sets), then a validation subset is held out of the
training pool, again at the frame level.

Usage:  python scripts/01_generate_synthetic_dataset.py [--seed 7] [--out data/synthetic]
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))  # make `psv` importable
import argparse, csv, json, os
import numpy as np
import cv2
from psv import synthetic as S, preprocessing as P, config as C

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=7)
ap.add_argument("--out", default="data/synthetic")
ap.add_argument("--per_class_per_split", type=int, default=150)
ap.add_argument("--shape", type=int, nargs=2, default=(480, 640))
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
demo_dir = "results/demo_synthetic"
os.makedirs(demo_dir, exist_ok=True)

rng = np.random.default_rng(args.seed)
shape = tuple(args.shape)
background_static = S.make_static_background(shape, rng)

# 50 flow-off reference frames (25 'start' + 25 'end' in the real experiment)
refs = [S.make_frame(background_static, rng, with_streaks=False, with_artifacts=False)[0]
        for _ in range(C.N_BACKGROUND_FRAMES)]
B, SD = P.build_background(refs, return_std=True)
np.savez_compressed(os.path.join(args.out, "background.npz"), mean=B, std=SD,
                    static=background_static)


def collect(split_name, first_frame_id):
    """Generate frames until each class has >= per_class_per_split patches."""
    need = args.per_class_per_split
    pat, lab, meta = [], [], []
    fid = first_frame_id
    n_by = {0: 0, 1: 0}
    while min(n_by.values()) < need:
        frame, truth = S.make_frame(background_static, rng)
        out = P.run_preprocessing(frame, B, SD)
        cands = out["candidates"]
        labels = S.label_candidates(cands, truth["streak_masks"], min_cover=0.3)
        for c, l in zip(cands, labels):
            pat.append(c.patch); lab.append(int(l))
            meta.append((fid, split_name, c.bbox, int(l), c.area))
            n_by[int(l)] += 1
        if fid == first_frame_id and split_name == "train":     # save a preview frame
            cv2.imwrite(os.path.join(demo_dir, "example_raw_frame.png"), frame)
        fid += 1
    pat, lab = np.stack(pat), np.array(lab)
    meta = np.array(meta, dtype=object)
    keep = []
    for cls in (0, 1):                                   # balanced random subsample
        idx = np.where(lab == cls)[0]
        keep.extend(rng.choice(idx, need, replace=False).tolist())
    keep = np.array(sorted(keep))
    return pat[keep], lab[keep], meta[keep], fid


Xtr, ytr, mtr, nxt = collect("train", 0)
Xte, yte, mte, nxt = collect("test", 100000)            # disjoint frame-id range
print(f"train patches {len(ytr)} (retained {ytr.sum()}), test patches {len(yte)} (retained {yte.sum()})")
print(f"frames used: train {len(set(m[0] for m in mtr))}, test {len(set(m[0] for m in mte))}")

# validation hold-out at FRAME level inside the training pool (~20 % of frames)
train_frames = sorted(set(m[0] for m in mtr))
val_frames = set(rng.choice(train_frames, max(1, len(train_frames) // 5), replace=False).tolist())
is_val = np.array([m[0] in val_frames for m in mtr])
assert not (set(m[0] for m in mtr) & set(m[0] for m in mte))     # no leakage


def save(name, X, y):
    np.savez_compressed(os.path.join(args.out, name),
                        X=(X * 255).astype(np.uint8), y=y)

save("train.npz", Xtr[~is_val], ytr[~is_val])
save("val.npz", Xtr[is_val], ytr[is_val])
save("test.npz", Xte, yte)

with open(os.path.join(args.out, "patch_index.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["subset", "frame_id", "x", "y", "w", "h", "area_px", "label"])
    for subset, M, msk in (("train", mtr, ~is_val), ("val", mtr, is_val),
                           ("test", mte, np.ones(len(mte), bool))):
        for m in M[msk]:
            w.writerow([subset, m[0], *m[2], m[4], m[3]])

summary = dict(seed=args.seed, frame_shape=list(shape),
               train=dict(n=int((~is_val).sum()), retained=int(ytr[~is_val].sum())),
               val=dict(n=int(is_val.sum()), retained=int(ytr[is_val].sum())),
               test=dict(n=int(len(yte)), retained=int(yte.sum())))
json.dump(summary, open(os.path.join(args.out, "dataset_summary.json"), "w"), indent=2)
print(json.dumps(summary, indent=2))

# a contact sheet of example patches
def sheet(X, y, cls, n=8):
    idx = np.where(y == cls)[0][:n]
    return np.hstack([cv2.resize(X[i], (112, 112)) for i in idx])
img = np.vstack([sheet(Xte, yte, 1), sheet(Xte, yte, 0)])
cv2.imwrite(os.path.join(demo_dir, "example_patches_top_retained_bottom_replaced.png"),
            (img * 255).astype(np.uint8))
