"""Evaluate the trained classifier on the held-out test patches.

Prints and saves accuracy, precision, recall and F1 with the *retained* class as
positive (the convention used in the manuscript), plus the confusion matrix.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))  # make `psv` importable
import argparse, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from psv.model import build_model
from psv.metrics import classification_metrics, plot_confusion

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/synthetic")
ap.add_argument("--weights", default="models/psv_cnn.weights.h5")
ap.add_argument("--out", default="results/demo_synthetic")
args = ap.parse_args()

d = np.load(os.path.join(args.data, "test.npz"))
X, y = (d["X"].astype(np.float32) / 255.0)[..., None], d["y"]
model = build_model()
model.load_weights(args.weights)
pred = model.predict(X, batch_size=16, verbose=0).argmax(1)
m = classification_metrics(y, pred)
print(json.dumps(m, indent=2))
os.makedirs(args.out, exist_ok=True)
json.dump(m, open(os.path.join(args.out, "test_metrics.json"), "w"), indent=2)
plot_confusion(m["confusion_matrix"], os.path.join(args.out, "confusion_matrix.png"),
               title="Confusion matrix on SYNTHETIC test patches")
np.save(os.path.join(args.out, "test_predictions.npy"), pred)
