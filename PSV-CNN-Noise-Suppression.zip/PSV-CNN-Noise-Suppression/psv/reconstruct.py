"""Classify candidates with the CNN and assemble the denoised full-field image."""
import cv2
import numpy as np


def classify_candidates(model, candidates, batch=16):
    """Return predicted class (0 replaced / 1 retained) and P(retained) per candidate."""
    if not candidates:
        return np.zeros(0, int), np.zeros(0)
    X = np.stack([c.patch for c in candidates])[..., None]
    p = model.predict(X, batch_size=batch, verbose=0)
    return p.argmax(1), p[:, 1]


def reconstruct(subtracted, candidates, pred, dilate_px=2):
    """Denoised frame: retained candidates keep their background-subtracted pixels,
    every replaced or unmatched region is set to the local background (= 0 after
    background subtraction)."""
    out = np.zeros_like(subtracted, dtype=np.float32)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * dilate_px + 1,) * 2)
    for c, keep in zip(candidates, pred):
        if keep == 1:
            m = cv2.dilate(c.mask.astype(np.uint8), k).astype(bool)
            out[m] = subtracted[m]
    return out
