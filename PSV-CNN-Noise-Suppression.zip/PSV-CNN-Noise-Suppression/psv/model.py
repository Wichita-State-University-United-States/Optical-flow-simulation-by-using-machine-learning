"""CNN streak classifier, exactly as described in manuscript Section 2.2 / Fig. 3.

Five blocks of [3x3 conv, stride 1, 'same' padding, ReLU, 2x2 max-pool, stride 2]
with 32, 64, 128, 256, 256 filters, then Flatten (7*7*256 = 12,544), Dense 1024 +
ReLU + Dropout 0.5, Dense 256 + ReLU + Dropout 0.5, Dense 2 + Softmax.
Class 0 = replaced, class 1 = retained.
"""
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from . import config as C


def build_model(input_size=C.PATCH_SIZE, init_std=C.INIT_STDDEV):
    init = keras.initializers.RandomNormal(mean=0.0, stddev=init_std)
    inp = keras.Input(shape=(input_size, input_size, 1), name="streak_patch")
    x = inp
    for i, f in enumerate(C.CONV_FILTERS, start=1):
        x = layers.Conv2D(f, 3, strides=1, padding="same", activation="relu",
                          kernel_initializer=init, name=f"conv{i}")(x)
        x = layers.MaxPooling2D(2, strides=2, name=f"pool{i}")(x)
    x = layers.Flatten(name="flatten")(x)
    for j, u in enumerate(C.FC_UNITS, start=1):
        x = layers.Dense(u, activation="relu", kernel_initializer=init, name=f"fc{j}")(x)
        x = layers.Dropout(C.DROPOUT, name=f"dropout{j}")(x)
    out = layers.Dense(2, activation="softmax", kernel_initializer=init, name="softmax")(x)
    model = keras.Model(inp, out, name="psv_streak_cnn")
    model.compile(
        optimizer=keras.optimizers.Adam(C.LEARNING_RATE, beta_1=C.ADAM_BETA1,
                                        beta_2=C.ADAM_BETA2),
        loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model


if __name__ == "__main__":
    m = build_model()
    m.summary()
    flat = m.get_layer("flatten").output.shape[-1]
    assert flat == 12544, flat
    print("Flatten size:", flat, "(matches the manuscript)")
