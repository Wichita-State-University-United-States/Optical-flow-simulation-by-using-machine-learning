"""Classification metrics (retained = positive class) and confusion-matrix plot."""
import numpy as np


def classification_metrics(y_true, y_pred):
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    n = tn + fp + fn + tp
    acc = (tp + tn) / n
    prec = tp / (tp + fp) if tp + fp else float("nan")
    rec = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else float("nan")
    # F1 of the other class (replaced as positive)
    p0 = tn / (tn + fn) if tn + fn else float("nan")
    r0 = tn / (tn + fp) if tn + fp else float("nan")
    f1_0 = 2 * p0 * r0 / (p0 + r0) if p0 + r0 else float("nan")
    return dict(n=n, accuracy=round(acc, 4), precision=round(prec, 4), recall=round(rec, 4),
                f1_retained=round(f1, 4), f1_replaced=round(f1_0, 4),
                confusion_matrix=[[tn, fp], [fn, tp]],
                note="rows = true (replaced, retained); columns = predicted (replaced, retained)")


def plot_confusion(cm, path, title="Confusion matrix"):
    import matplotlib.pyplot as plt
    cm = np.array(cm)
    pct = cm / cm.sum(axis=1, keepdims=True) * 100
    fig, ax = plt.subplots(figsize=(4.6, 4.4))
    ax.imshow(pct, cmap="Blues", vmin=0, vmax=100)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{cm[i, j]}\n({pct[i, j]:.1f}%)", ha="center", va="center",
                    color="white" if pct[i, j] > 50 else "black", fontsize=12)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Replaced", "Retained"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["Replaced", "Retained"])
    ax.set_xlabel("Predicted label"); ax.set_ylabel("True label"); ax.set_title(title, fontsize=10)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
