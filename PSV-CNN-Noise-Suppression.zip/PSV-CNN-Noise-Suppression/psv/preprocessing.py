"""Image preprocessing: background subtraction, enhancement, adaptive threshold,
contour-based candidate extraction and patch cropping (manuscript Section 2.1)."""
from dataclasses import dataclass
import cv2
import numpy as np
from . import config as C


@dataclass
class Candidate:
    """One contour-based streak candidate."""
    bbox: tuple            # (x, y, w, h) in frame pixels
    mask: np.ndarray       # bool mask, full-frame size
    area: int
    patch: np.ndarray = None   # float32 (224, 224) in [0, 1]


def to_gray_float(img):
    """Return a 2-D float32 image on a 0-255 scale."""
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = img.astype(np.float32)
    if img.max() > 255.0:                      # e.g. 12/16-bit camera data
        img = img / img.max() * 255.0
    return img


def build_background(frames, return_std=False):
    """Average N flow-off reference frames -> static background estimate.

    With return_std=True also returns the per-pixel standard deviation over the
    reference stack, which is a direct measurement of the temporal noise floor."""
    stack = np.stack([to_gray_float(f) for f in frames], axis=0)
    if return_std:
        return stack.mean(axis=0), stack.std(axis=0)
    return stack.mean(axis=0)


def subtract_background(frame, background, noise_std=None, k=C.NOISE_FLOOR_K):
    """Subtract the static background; negative values are clipped to zero.

    If `noise_std` is given, k * noise_std is subtracted as well so that pure
    sensor noise does not survive as small positive values [assumed step]."""
    out = to_gray_float(frame) - background
    if noise_std is not None:
        out = out - k * noise_std
    return np.clip(out, 0.0, 255.0)


def enhance_contrast(img, method="stretch", smooth=C.SMOOTH_KSIZE,
                     clip=C.CLAHE_CLIP, tile=C.CLAHE_TILE):
    """Adaptive contrast enhancement -> uint8 image.

    method="stretch" (default): linearly stretch the non-zero intensity range of
        THIS image (1st to 99.5th percentile) onto 0-255. Zero pixels stay zero,
        and the stretch adapts automatically to pulsed (40-220) or continuous
        (120-200) illumination, as the manuscript requires.
    method="clahe": OpenCV CLAHE. Note that CLAHE lifts zero pixels, which
        weakens the later 'percentile of non-zero pixels' threshold.
    The manuscript does not name the enhancement operator [assumed].
    """
    f = np.clip(img, 0, 255).astype(np.float32)
    if smooth and smooth > 1:
        f = cv2.GaussianBlur(f, (smooth, smooth), 0)
    if method == "clahe":
        clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
        return clahe.apply(f.astype(np.uint8))
    nz = f[f > 0]
    if nz.size < 10:
        return np.zeros(f.shape, np.uint8)
    lo, hi = np.percentile(nz, 1.0), np.percentile(nz, 99.5)
    out = np.clip((f - lo) / max(hi - lo, 1e-6), 0.0, 1.0) * 254.0 + 1.0
    out[f <= 0] = 0.0
    return out.astype(np.uint8)


def adaptive_threshold(img_u8, percentile=C.THRESHOLD_PERCENTILE):
    """Zero every pixel below the given percentile of the NON-ZERO intensities.

    Pixels at or above the threshold keep their original intensity (Fig. 2).
    Returns (thresholded image, threshold value)."""
    nz = img_u8[img_u8 > 0]
    if nz.size == 0:
        return np.zeros_like(img_u8), 0.0
    thr = float(np.percentile(nz, percentile))
    out = img_u8.copy()
    out[out < thr] = 0
    return out, thr


def crop_patch(img, bbox, size=C.PATCH_SIZE, margin=C.PATCH_MARGIN):
    """Square crop around a bounding box, aspect-preserving resize to size x size."""
    x, y, w, h = bbox
    side = max(int(round(max(w, h) * (1.0 + 2 * margin))), 8)
    cx, cy = x + w / 2.0, y + h / 2.0
    x0, y0 = int(round(cx - side / 2.0)), int(round(cy - side / 2.0))
    canvas = np.zeros((side, side), np.float32)
    H, W = img.shape[:2]
    sx0, sy0 = max(x0, 0), max(y0, 0)
    sx1, sy1 = min(x0 + side, W), min(y0 + side, H)
    if sx1 > sx0 and sy1 > sy0:
        canvas[sy0 - y0:sy1 - y0, sx0 - x0:sx1 - x0] = img[sy0:sy1, sx0:sx1]
    patch = cv2.resize(canvas, (size, size), interpolation=cv2.INTER_AREA)
    return np.clip(patch / 255.0, 0.0, 1.0).astype(np.float32)


def extract_candidates(thresholded, source, min_area=C.MIN_CONTOUR_AREA,
                       size=C.PATCH_SIZE, margin=C.PATCH_MARGIN):
    """Find contours, drop small structures, and crop one patch per candidate.

    `source` is the image the patches are cropped from (the enhanced frame)."""
    binary = (thresholded > 0).astype(np.uint8)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cands = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < min_area:
            continue
        x, y, w, h = cv2.boundingRect(cnt)
        mask = np.zeros(binary.shape, np.uint8)
        cv2.drawContours(mask, [cnt], -1, 1, thickness=-1)
        cand = Candidate(bbox=(x, y, w, h), mask=mask.astype(bool), area=int(area))
        cand.patch = crop_patch(source, cand.bbox, size, margin)
        cands.append(cand)
    return cands


def run_preprocessing(frame, background, noise_std=None,
                      percentile=C.THRESHOLD_PERCENTILE, min_area=C.MIN_CONTOUR_AREA):
    """Full Fig. 1 chain for one frame. Returns a dict of every intermediate."""
    sub = subtract_background(frame, background, noise_std)
    enh = enhance_contrast(sub)
    thr_img, thr = adaptive_threshold(enh, percentile)
    cands = extract_candidates(thr_img, enh, min_area=min_area)
    return dict(subtracted=sub, enhanced=enh, thresholded=thr_img,
                threshold=thr, candidates=cands)
