"""Synthetic PSV frame generator with ground truth.

The real experimental frames and the manually labelled 600-patch dataset are not
part of this repository. This module produces *synthetic* frames so the whole
pipeline can be run and tested end to end. Results obtained on synthetic data are
a demonstration of the code, NOT a reproduction of the numbers in the paper.

Each frame contains
  * a static background (illumination gradient, fixed speckle, wall edges),
    identical in every frame of one "experiment" and removable by background
    averaging,
  * per-frame sensor noise,
  * true streaks (the signal) drawn left to right with a Poiseuille-like
    length distribution,
  * per-frame structured artifacts: specular reflections, defocused particle
    halos, hot-pixel clusters and short scratches.
"""
import cv2
import numpy as np


def make_static_background(shape, rng):
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    bg = 18 + 10 * (xx / w) + 8 * np.sin(yy / h * np.pi)           # illumination gradient
    speck = (rng.random((h, w)) > 0.9985).astype(np.float32) * rng.uniform(25, 60)
    bg += cv2.GaussianBlur(speck, (0, 0), 1.2)                     # fixed dust / scratches
    bg[:6, :] += 40
    bg[-6:, :] += 40                                               # channel walls
    return bg


def _draw_streak(canvas, cx, cy, length, angle_deg, width, peak):
    """Draw one streak with a Gaussian cross-section and tapered ends. Returns its mask."""
    h, w = canvas.shape
    rad = np.deg2rad(angle_deg)
    d = np.array([np.cos(rad), np.sin(rad)])
    n = np.array([-d[1], d[0]])
    half = length / 2.0
    pad = int(half + 4 * width + 4)
    x0, x1 = max(int(cx - pad), 0), min(int(cx + pad), w)
    y0, y1 = max(int(cy - pad), 0), min(int(cy + pad), h)
    if x1 <= x0 or y1 <= y0:
        return None
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    s = (xx - cx) * d[0] + (yy - cy) * d[1]           # along
    t = (xx - cx) * n[0] + (yy - cy) * n[1]           # across
    along = np.clip((half - np.abs(s)) / 3.0, 0, 1)   # soft ends
    prof = np.exp(-0.5 * (t / width) ** 2) * along
    canvas[y0:y1, x0:x1] += peak * prof
    mask = np.zeros(canvas.shape, bool)
    mask[y0:y1, x0:x1] = prof > 0.35
    return mask


def make_frame(background, rng, n_streaks=22, with_streaks=True, with_artifacts=True,
               sensor_sigma=3.0):
    """Return (frame uint8, truth dict). truth['streak_masks'] is a list of bool masks."""
    h, w = background.shape
    sig = np.zeros((h, w), np.float32)
    streak_masks, streak_params = [], []
    if with_streaks:
        for _ in range(n_streaks):
            cy = rng.uniform(25, h - 25)
            # Poiseuille-like: faster (longer) streaks near mid-height
            prof = 4 * (cy / h) * (1 - cy / h)
            length = 25 + 95 * prof * rng.uniform(0.75, 1.1)
            cx = rng.uniform(70, w - 70)
            m = _draw_streak(sig, cx, cy, length,
                             rng.uniform(-4, 4), rng.uniform(1.2, 2.2),
                             rng.uniform(95, 215))
            if m is not None:
                streak_masks.append(m)
                streak_params.append(dict(cx=float(cx), cy=float(cy), length=float(length)))
    art = np.zeros((h, w), np.float32)
    if with_artifacts:
        for _ in range(rng.integers(4, 9)):            # specular reflections
            cx, cy = rng.uniform(20, w - 20), rng.uniform(20, h - 20)
            ax, ay = rng.uniform(4, 11), rng.uniform(3, 9)
            ang = rng.uniform(0, 180)
            cv2.ellipse(art, (int(cx), int(cy)), (int(ax), int(ay)), ang, 0, 360,
                        float(rng.uniform(170, 250)), -1)
        for _ in range(rng.integers(5, 11)):           # defocused halos
            cx, cy = int(rng.uniform(30, w - 30)), int(rng.uniform(30, h - 30))
            blob = np.zeros((h, w), np.float32)
            blob[cy, cx] = 1.0
            art += cv2.GaussianBlur(blob, (0, 0), rng.uniform(5, 11)) * rng.uniform(900, 2200)
        for _ in range(rng.integers(30, 70)):          # hot pixel clusters
            cx, cy = rng.integers(0, w), rng.integers(0, h)
            art[cy:cy + 2, cx:cx + 2] += rng.uniform(120, 255)
        for _ in range(rng.integers(2, 6)):            # short scratches at random angles
            cx, cy = rng.uniform(30, w - 30), rng.uniform(30, h - 30)
            L = rng.uniform(10, 24)
            a = np.deg2rad(rng.uniform(0, 180))
            p0 = (int(cx - L / 2 * np.cos(a)), int(cy - L / 2 * np.sin(a)))
            p1 = (int(cx + L / 2 * np.cos(a)), int(cy + L / 2 * np.sin(a)))
            cv2.line(art, p0, p1, float(rng.uniform(110, 200)), 2)
    frame = background + sig + art + rng.normal(0, sensor_sigma, (h, w)).astype(np.float32)
    return (np.clip(frame, 0, 255).astype(np.uint8),
            dict(streak_masks=streak_masks, streak_params=streak_params))


def label_candidates(candidates, streak_masks, min_cover=0.6, min_purity=0.5):
    """Automatic ground-truth label for each extracted candidate.

    retained (1): the candidate overlaps exactly ONE true streak, covers at least
                  `min_cover` of it, and at least `min_purity` of the candidate
                  area belongs to that streak.
    replaced (0): everything else (artifacts, background, overlapping streaks).
    This mirrors the paper's rule that overlapping regions are classified as bad.
    """
    labels = []
    for c in candidates:
        hits = []
        for sm in streak_masks:
            inter = np.logical_and(c.mask, sm).sum()
            if inter > 0:
                hits.append((inter, sm.sum()))
        if len(hits) == 1:
            inter, ssum = hits[0]
            ok = inter / max(ssum, 1) >= min_cover and inter / max(c.mask.sum(), 1) >= min_purity
            labels.append(1 if ok else 0)
        else:
            labels.append(0)
    return np.array(labels, dtype=np.int64)
