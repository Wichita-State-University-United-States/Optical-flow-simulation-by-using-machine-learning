"""PSV-CNN: noise suppression and velocity reconstruction for Particle Streak Velocimetry."""
__version__ = "1.0.0"
