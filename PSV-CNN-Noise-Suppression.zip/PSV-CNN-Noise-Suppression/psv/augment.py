"""Training-set augmentation (manuscript Section 2.3): rotation up to +/-30 deg,
horizontal and vertical flips, scaling by +/-10 %, then crop/pad back to the
original dimensions. The test set is never augmented."""
import cv2
import numpy as np
from . import config as C


def augment_patch(patch, rng):
    out = patch
    if rng.random() < 0.5:
        out = out[:, ::-1]
    if rng.random() < 0.5:
        out = out[::-1, :]
    h, w = out.shape
    angle = rng.uniform(-C.AUG_ROTATION_DEG, C.AUG_ROTATION_DEG)
    scale = 1.0 + rng.uniform(-C.AUG_SCALE, C.AUG_SCALE)
    M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, scale)   # keeps size -> crop/pad
    out = cv2.warpAffine(np.ascontiguousarray(out), M, (w, h),
                         flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT,
                         borderValue=0)
    return out.astype(np.float32)


def augment_batch(X, rng):
    """X: (N, H, W) or (N, H, W, 1) float32 -> same shape, augmented."""
    squeeze = X.ndim == 4
    arr = X[..., 0] if squeeze else X
    res = np.stack([augment_patch(p, rng) for p in arr])
    return res[..., None] if squeeze else res
