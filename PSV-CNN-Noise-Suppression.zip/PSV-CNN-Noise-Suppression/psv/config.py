"""All pipeline constants in one place.

Values marked [paper] are stated in the manuscript. Values marked [assumed] are
NOT specified in the manuscript and were chosen by the code author; change them
to match your own processing if they differ.
"""

# ---- Imaging / experiment [paper, Section 3] --------------------------------
PIXEL_SIZE_UM = 0.265          # um per pixel at the object plane
FRAME_SHAPE = (1082, 1312)     # (rows, cols) of a raw frame
EXPOSURE_S = 0.045             # 45 ms exposure
PARTICLE_DIAMETER_UM = 20.0    # polystyrene tracer, ~75 px across

# ---- Preprocessing [paper, Section 2.1] -------------------------------------
N_BACKGROUND_FRAMES = 50       # 25 from start + 25 from end of the sequence
THRESHOLD_PERCENTILE = 85.0    # of the non-zero pixel intensities
PATCH_SIZE = 224               # CNN input is 224 x 224 x 1

# ---- Preprocessing [assumed] ------------------------------------------------
NOISE_FLOOR_K = 3.0            # subtract k * per-pixel std of the reference stack
CLAHE_CLIP = 2.0               # only used when method='clahe' (operator not named)
CLAHE_TILE = 8
SMOOTH_KSIZE = 3               # light Gaussian smoothing before the threshold (0 = off)
MIN_CONTOUR_AREA = 40          # px, "minimum area threshold" (value not given)
PATCH_MARGIN = 0.15            # fractional margin added around each bounding box

# ---- CNN [paper, Section 2.2] -----------------------------------------------
CONV_FILTERS = (32, 64, 128, 256, 256)
FC_UNITS = (1024, 256)
DROPOUT = 0.5
LEARNING_RATE = 1e-3
ADAM_BETA1, ADAM_BETA2 = 0.9, 0.999
EPOCHS_PAPER = 100
CLASS_NAMES = ("replaced", "retained")   # index 0, index 1

# ---- CNN [assumed] ----------------------------------------------------------
BATCH_SIZE = 16
INIT_STDDEV = 0.02             # "normal distribution" (sigma not given)

# ---- Augmentation [paper, Section 2.3] --------------------------------------
AUG_ROTATION_DEG = 30.0
AUG_SCALE = 0.10

# ---- Flow / validation [paper, Section 4.2] ---------------------------------
H_MM = 0.9                     # channel depth
W_MM = 5.0                     # channel width
RE = 2.4
NU_M2S = 1.0e-6
DH_MM = 1.525
U_MEAN_MMS = 1.575
U_MAX_MMS = 1.5 * U_MEAN_MMS   # 2.3625 mm/s (rounded to 2.36 in the text)
