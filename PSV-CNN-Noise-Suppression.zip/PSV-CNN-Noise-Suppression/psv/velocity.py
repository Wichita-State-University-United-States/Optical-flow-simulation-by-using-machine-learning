"""Streak geometry -> velocity, analytical Poiseuille reference, and the MVNAE metric."""
import cv2
import numpy as np
from . import config as C


# ---- analytical reference ----------------------------------------------------
def poiseuille_velocity(z_mm, H_mm=C.H_MM, u_max=C.U_MAX_MMS):
    """Planar Poiseuille profile u(z) = 4 u_max (z/H)(1 - z/H)  [mm/s]."""
    z = np.asarray(z_mm, dtype=float)
    return 4.0 * u_max * (z / H_mm) * (1.0 - z / H_mm)


def hydraulic_diameter(W_mm=C.W_MM, H_mm=C.H_MM):
    return 2.0 * W_mm * H_mm / (W_mm + H_mm)


def reynolds(u_mean_mms=C.U_MEAN_MMS, Dh_mm=None, nu_m2s=C.NU_M2S):
    Dh_mm = hydraulic_diameter() if Dh_mm is None else Dh_mm
    return (u_mean_mms * 1e-3) * (Dh_mm * 1e-3) / nu_m2s


# ---- error metric ------------------------------------------------------------
def mvnae(u_psv, u_ref, u_max):
    """Maximum-velocity-normalised absolute error, in percent, per position:
        eps_i = |u_PSV,i - u_ref,i| / u_max * 100
    NOT a conventional relative error (the denominator is the global maximum)."""
    return np.abs(np.asarray(u_psv, float) - np.asarray(u_ref, float)) / u_max * 100.0


def error_summary(eps):
    eps = np.asarray(eps, float)
    return dict(n=int(eps.size), mean=float(eps.mean()),
                rms=float(np.sqrt((eps ** 2).mean())), max=float(eps.max()),
                n_le_5pct=int((eps <= 5.0 + 1e-9).sum()))


# ---- streak geometry ---------------------------------------------------------
def streak_geometry(mask):
    """Major-axis length (px) and orientation (deg, in (-90, 90]) of a binary mask.

    Length is the extent of the mask projected on its principal axis."""
    ys, xs = np.nonzero(mask)
    if xs.size < 3:
        return 0.0, 0.0, (float(xs.mean()) if xs.size else 0.0, float(ys.mean()) if ys.size else 0.0)
    pts = np.column_stack([xs, ys]).astype(np.float32)
    mean = pts.mean(axis=0)
    u, s, vt = np.linalg.svd(pts - mean, full_matrices=False)
    axis = vt[0]
    proj = (pts - mean) @ axis
    length = float(proj.max() - proj.min() + 1.0)
    angle = float(np.degrees(np.arctan2(axis[1], axis[0])))
    if angle > 90: angle -= 180
    if angle <= -90: angle += 180
    return length, angle, (float(mean[0]), float(mean[1]))


def streak_speed_mms(length_px, pixel_um=C.PIXEL_SIZE_UM, exposure_s=C.EXPOSURE_S,
                     particle_diameter_px=0.0):
    """Speed from streak length: v = (L - d) * pixel / t_exposure  [mm/s].

    The manuscript states that streak length is proportional to speed for a fixed
    illumination duration but does not say whether the particle image diameter
    (~75 px) is subtracted. It is a parameter here; default 0 (no subtraction)."""
    return max(length_px - particle_diameter_px, 0.0) * pixel_um * 1e-3 / exposure_s


def signed_vector(angle_deg, speed, flow_direction=(1.0, 0.0)):
    """Vector from streak orientation; sign fixed by the known bulk-flow direction
    (the CNN does not infer forward vs backward motion, as stated in the paper)."""
    d = np.array([np.cos(np.radians(angle_deg)), np.sin(np.radians(angle_deg))])
    if d @ np.asarray(flow_direction, float) < 0:
        d = -d
    return speed * d
