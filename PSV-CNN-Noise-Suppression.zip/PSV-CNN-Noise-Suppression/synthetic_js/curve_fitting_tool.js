// Particle-path streaks from a simple analytic flow field with velocity arrows drawn from that field.
// Run:  node curve_fitting_tool.js [output_folder]
// --- Setup for the environment (Required for Node.js/Canvas) ---
const { createCanvas } = require('canvas');
const fs = require('fs');
const OUT_DIR = process.argv[2] || __dirname;   // output folder (optional first argument)

// 1. Define staticCanvas (400x400)
const W = 400;
const H = 400;
const staticCanvas = createCanvas(W, H);
const ctx_static = staticCanvas.getContext('2d');

// Clear the canvas to black
ctx_static.fillStyle = 'black';
ctx_static.fillRect(0, 0, W, H);

// --- Simulation Setup ---
const NUM_PARTICLES = 50;
const particles = [];
const FLOW_FIELD_STRENGTH = 0.5; // Controls the magnitude of the flow

// Simple Flow Field: Constant downward flow with slight horizontal variation
function getFlowVector(x, y) {
    // Base flow is straight down (0, 1)
    let vx = 0;
    let vy = 1;

    // Add a slight horizontal variation based on x-position (e.g., a gentle swirl)
    // This makes the "curve fitting" concept more relevant
    vx = Math.sin(x / W * Math.PI * 2) * 0.2; // Gentle sine wave variation
    vy = 1 + Math.cos(y / H * Math.PI) * 0.1; // Slight speed variation

    // Normalize and scale the vector
    const magnitude = Math.sqrt(vx * vx + vy * vy);
    vx = (vx / magnitude) * FLOW_FIELD_STRENGTH;
    vy = (vy / magnitude) * FLOW_FIELD_STRENGTH;

    return { vx, vy };
}

// Particle class to hold state
class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.history = [{ x, y }]; // To store the path for the streak
        this.maxHistory = 10; // Length of the streak
        this.alpha = 0.5 + Math.random() * 0.5; // Random alpha for intensity variation
    }

    update() {
        const flow = getFlowVector(this.x, this.y);
        this.x += flow.vx * 5; // Move faster for a visible streak
        this.y += flow.vy * 5;

        // Wrap around the screen
        if (this.y > H) {
            this.y = 0;
            this.x = Math.random() * W; // Reset x randomly
            this.history = [{ x: this.x, y: this.y }];
        }

        // Update history
        this.history.push({ x: this.x, y: this.y });
        if (this.history.length > this.maxHistory) {
            this.history.shift();
        }
    }

    drawStreak() {
        if (this.history.length < 2) return;

        // Draw the streak as a path
        ctx_static.beginPath();
        ctx_static.moveTo(this.history[0].x, this.history[0].y);

        for (let i = 1; i < this.history.length; i++) {
            const p = this.history[i];
            // Use a gradient along the streak for intensity variation
            const alpha = this.alpha * (i / this.history.length);
            ctx_static.strokeStyle = `rgba(100, 255, 255, ${alpha})`;
            ctx_static.lineTo(p.x, p.y);
        }
        ctx_static.lineWidth = 1;
        ctx_static.stroke();
    }

    drawVelocityVector() {
        const p = this.history[this.history.length - 1]; // Current position
        const flow = getFlowVector(p.x, p.y);
        const vectorLength = 20;

        const endX = p.x + flow.vx * vectorLength;
        const endY = p.y + flow.vy * vectorLength;

        // Draw the vector (a simple line for now)
        ctx_static.strokeStyle = 'red'; // Velocity vectors in red
        ctx_static.lineWidth = 2;
        ctx_static.beginPath();
        ctx_static.moveTo(p.x, p.y);
        ctx_static.lineTo(endX, endY);
        ctx_static.stroke();

        // Draw an arrowhead (simple triangle)
        const headlen = 5;
        const angle = Math.atan2(endY - p.y, endX - p.x);
        ctx_static.fillStyle = 'red';
        ctx_static.beginPath();
        ctx_static.moveTo(endX, endY);
        ctx_static.lineTo(endX - headlen * Math.cos(angle - Math.PI / 6), endY - headlen * Math.sin(angle - Math.PI / 6));
        ctx_static.lineTo(endX - headlen * Math.cos(angle + Math.PI / 6), endY - headlen * Math.sin(angle + Math.PI / 6));
        ctx_static.closePath();
        ctx_static.fill();
    }
}

// Initialize particles
for (let i = 0; i < NUM_PARTICLES; i++) {
    particles.push(new Particle(Math.random() * W, Math.random() * H));
}

// Simulate multiple steps to generate visible streaks
const SIMULATION_STEPS = 10;
for (let step = 0; step < SIMULATION_STEPS; step++) {
    particles.forEach(p => p.update());
}

// Draw the final frame
particles.forEach(p => p.drawStreak());
particles.forEach(p => p.drawVelocityVector());


// --- Save the output to a file (Required for Node.js/Canvas) ---
const out = fs.createWriteStream(OUT_DIR + '/output.png');
const stream = staticCanvas.createPNGStream();
stream.pipe(out);
out.on('finish', () =>  console.log('The PNG file was created.'));
