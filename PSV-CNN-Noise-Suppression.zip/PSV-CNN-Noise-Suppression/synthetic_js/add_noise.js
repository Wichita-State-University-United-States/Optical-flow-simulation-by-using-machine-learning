// Same streak generator plus salt-and-pepper noise (4000 pixels).
// Run:  node add_noise.js [output_folder]
// --- Setup for the environment (Required for Node.js/Canvas) ---
const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const OUT_DIR = process.argv[2] || __dirname;   // output folder (optional first argument)

// 1. Define staticCanvas (400x400)
const staticCanvas = createCanvas(400, 400);
const ctx_static = staticCanvas.getContext('2d');

// 2. Define the 'static' point (Used by the original distToPoint function, kept for completeness)
const static = { x: staticCanvas.width / 2, y: staticCanvas.height / 2 }; // Center point

// 3. Define the distToPoint function (Kept for completeness, though not used in the new streak logic)
function distToPoint(x1, y1, p2) {
    const dx = x1 - p2.x;
    const dy = y1 - p2.y;
    return Math.sqrt(dx * dx + dy * dy);
}

// Clear the canvas to black (or any background)
ctx_static.fillStyle = 'black';
ctx_static.fillRect(0, 0, staticCanvas.width, staticCanvas.height);

// --- NEW: Background Noise (Small, low-intensity white dots) ---
const NOISE_DOTS = 1000;
ctx_static.fillStyle = 'rgba(255, 255, 255, 0.02)'; // Very low opacity white
for (let i = 0; i < NOISE_DOTS; i++) {
    const x = Math.random() * staticCanvas.width;
    const y = Math.random() * staticCanvas.height;
    ctx_static.fillRect(x, y, 1, 1); // Draw a 1x1 pixel dot
}

// --- Modified Drawing Logic: Draw many random streaks with wider intensity variation and overlapping ---
const NUM_STREAKS = 150; // Increased number for overlapping
for (let i = 0; i < NUM_STREAKS; i++) {
    const x = Math.round(Math.random() * staticCanvas.width);
    const y = Math.round(Math.random() * staticCanvas.height * 0.9); // Start in the top 90%
    const length = 10 + Math.random() * 40; // Streak length between 10 and 50
    
    // Wider random alpha range for more variation, including very low intensity (0.1 to 0.8)
    const alpha = 0.1 + Math.random() * 0.7; 
    
    // Random line width for more noise (1 to 2 pixels)
    const lineWidth = 1 + Math.random();

    // Create a vertical linear gradient for the streak
    const streakGrad = ctx_static.createLinearGradient(x, y, x, y + length);
    // Fades from bright white to transparent
    streakGrad.addColorStop(0, `rgba(255, 255, 255, ${alpha})`); // Brightest at the top (Pure White)
    streakGrad.addColorStop(0.8, `rgba(255, 255, 255, ${alpha * 0.5})`); // Fading color (Pure White)
    streakGrad.addColorStop(1, 'rgba(0, 0, 0, 0)'); // Fully transparent at the bottom

    ctx_static.strokeStyle = streakGrad;
    ctx_static.lineWidth = lineWidth; // Use random line width

    // Draw the vertical line (streak)
    ctx_static.beginPath();
    ctx_static.moveTo(x, y);
    ctx_static.lineTo(x, y + length);
    ctx_static.stroke();
}

// --- NEW: Salt and Pepper Noise ---
const NOISE_PIXELS = 4000; // Number of pixels to affect (400*400 = 160000 total)
for (let i = 0; i < NOISE_PIXELS; i++) {
    const x = Math.floor(Math.random() * staticCanvas.width);
    const y = Math.floor(Math.random() * staticCanvas.height);
    
    // 50% chance for white (salt), 50% chance for black (pepper)
    const color = Math.random() < 0.5 ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.8)';
    
    ctx_static.fillStyle = color;
    ctx_static.fillRect(x, y, 1, 1);
}

// --- Original Crosshair Logic (Kept for completeness) ---
// Draw crosshair lines at a random static point
const s1x = Math.round(staticCanvas.width * Math.random());
const s1y = Math.round(staticCanvas.height * Math.random());
const s1Grad = ctx_static.createRadialGradient(s1x, s1y, 0, s1x, s1y, 20);
s1Grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
s1Grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
ctx_static.strokeStyle = s1Grad;
ctx_static.lineWidth = 1; // Ensure line is visible

// Horizontal line
ctx_static.beginPath();
ctx_static.moveTo(s1x - 4, s1y);
ctx_static.lineTo(s1x + 4, s1y);
ctx_static.stroke();

// Vertical line
ctx_static.beginPath();
ctx_static.moveTo(s1x, s1y - 4);
ctx_static.lineTo(s1x, s1y + 4);
ctx_static.stroke();

// --- Save the output to a file (Required for Node.js/Canvas) ---
const out = fs.createWriteStream(OUT_DIR + '/output.png');
const stream = staticCanvas.createPNGStream();
stream.pipe(out);
out.on('finish', () =>  console.log('The PNG file has been created.'));
