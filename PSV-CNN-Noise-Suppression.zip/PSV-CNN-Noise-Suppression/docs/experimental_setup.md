# Experimental setup (manuscript Section 3)

| Item | Value |
|---|---|
| Channel | PDMS, vertical, 60 mm long, 5 mm wide, 0.9 mm deep, single inlet and outlet |
| Fluid | deionized water |
| Tracers | non-fluorescent polystyrene, 20 um diameter, 0.1 g per 100 g |
| Pumping | precision micro-injection pumps (Arduino-controlled syringe pump) |
| Illumination | 5 W pulsed RGB LED light sheet, or constant-intensity sheet; cylindrical lens f = 50 mm; sheet thickness about 0.18 mm FWHM |
| Optics | 20x plan achromat, NA 0.40, 1.51x adapter, 0.265 um per pixel, depth of field about 1.4 um |
| Camera | 12-bit CMOS, 8.0 um pixel pitch, 1312 x 1082 px, exposure 45 ms |
| Field of view | 347.7 x 286.7 um, centred 3.5 mm from the channel wall |
| Frames | 300 per illumination mode |
| Flow | Re = 2.4 (bulk mean velocity, D_h = 1.525 mm), u_mean = 1.575 mm/s, u_max = 2.363 mm/s |

Machine-readable copy: `data/reported/experimental_setup.json`.

Consistency checks (computed in `scripts/05_reproduce_reported_results.py`):

* D_h = 2WH / (W + H) = 1.525 mm
* Re = u_mean D_h / nu = 2.40
* field of view = 1312 x 0.265 = 347.7 um by 1082 x 0.265 = 286.7 um
* particle image = 20 / 0.265 = 75 px
* a streak at u_max over a 45 ms exposure spans about 400 px (about 106 um)

Illumination modes: pulsed streak intensity spans roughly 40 to 220 (0 to 255 scale); continuous illumination gives roughly 120 to 200.
