# Reproducibility notes

An honest statement of what this repository does and does not let you reproduce.

## 1. What can be reproduced exactly
* Every statistic quoted from the velocity-profile table: mean 2.64 %, RMS 3.19 %, maximum 7.28 %, 19 of 20 points at or below 5 % (`scripts/05_reproduce_reported_results.py`).
* Confusion-matrix metrics from Fig. 7 (accuracy 0.997, precision 1.000, recall 0.993, F1 0.997).
* Consistency of the flow and optics numbers (D_h, Re, field of view, particle image size, expected streak length).
* The CNN architecture, including the 12,544 flatten size and 14,086,914 parameters (`python -m psv.model`).

## 2. What is NOT included, and why it matters
| Missing item | Consequence |
|---|---|
| Raw experimental frames (2 x 300) | The pipeline cannot be re-run on the real data from this repository. |
| The 600 manually labelled patches | The 99.7 % test accuracy cannot be re-derived. |
| Trained weights and the original TensorFlow training script | Fig. 6, Fig. 7 and Table 2 cannot be regenerated. |
| Per-epoch training log behind Fig. 6 | Fig. 6 is shipped only as the published image. |
| Per-position standard deviations behind the 1-sigma bars of Fig. 11(a) | The regenerated Fig. 11 omits error bars unless you pass `--sigma_csv`. |
| Protocol that maps each streak to a depth position z | Cannot be reconstructed from the text. |

The preprocessing and training code here was written from the manuscript description. Parameters the paper does not give are marked `[assumed]` in `psv/config.py` (enhancement operator, noise floor, minimum contour area, patch margin, batch size, initialiser spread).

## 3. Synthetic demonstration results are not paper results
`scripts/01` to `04` generate synthetic frames with known ground truth, train the same CNN on them, and run the whole chain. Numbers from that run (87.7 % test accuracy, recall 1.0, 37 false positives on the synthetic test patches) describe the demo only. All errors are "replaced" patches predicted as "retained". In a visual check of the 37 false positives, most were overlapping or adjacent streaks merged into a single contour (they look like one valid long streak), with a few thick blurred streaks; overlaps are the case the paper handles by classifying them as "replaced". The demo was trained for 25 epochs with no tuning toward the paper's numbers.

## 4. Items in the original source files that were deliberately left out
While assembling this project, the following were found in the files supplied by the authors. They are listed so the authors can decide how to handle them before the repository goes public.

1. **`psv_cnn_data_model.py` describes an earlier version of the work.** It carries the old title and author list, F1 = 0.98, "overall accuracy" 97.4 %, a 298 / 2 confusion matrix, and a PyTorch network with batch normalisation, a 4 x 4 adaptive pooling layer and 512 / 128 dense units. The final manuscript reports F1 = 0.997, a 150 / 0 / 1 / 149 matrix, and a TensorFlow network with a 7 x 7 x 256 flatten and 1024 / 256 dense units. Publishing the old file next to the new paper would be contradictory, so it is not included.
2. **Figure 6 in that file is produced by analytic functions, not by a logged run.** `_simulated_training_curves()` draws sigmoid and exponential curves with random noise and then overwrites the last 21 epochs with fixed means (0.990, 0.981, 0.038, 0.051). If the published Fig. 6 came from this function, it should be replaced by the real Keras history before the repository or paper claims it is a training record. The training script here (`02_train_cnn.py`) writes a genuine per-epoch history instead.
3. **The same file builds the Fig. 11 "1-sigma" error bars as 0.6 x the point error.** That is not a measured standard deviation. If the published error bars were made that way, they should be recomputed from repeated measurements.
4. **In the same file the "validation" loader is the test loader and the split is 90/10 on synthetic images,** which differs from the manuscript's frame-level 50:50 split with a separate validation subset.
5. **Stage 3 of `synthetic_js/streak_pipeline_demo.js` does not denoise anything.** It clears the canvas and redraws a new clean random image (comment in the original: "Conceptual Denoising"). In a test run the correlation between the stage 2 noisy image and the stage 3 "denoised" image was 0.008, versus 0.52 between stage 1 and stage 2. These JavaScript tools are included only as synthetic image generators. They should not be described as the output of the CNN pipeline. If the paper's Fig. 8 was made with them, the caption and text of Section 4.2 should say so, or the figure should be regenerated with `scripts/04_denoise_and_measure_demo.py`.
6. **Table 2 baselines are not reproducible from the text.** "Gaussian blur + common candidate extraction" and the other filtering baselines are passed through a "common decision workflow" whose decision rule is not defined, so no code for them is provided.

## 5. Scientific points a reader may raise
* `u_max = 1.5 u_mean` is exact for infinite parallel plates. At aspect ratio W/H = 5.56 the ratio of centreline to mean velocity differs, and the field of view sits 3.5 mm from one wall of a 5 mm channel, 1.5 mm from the other, so side-wall effects are not obviously negligible. Quantifying this, or citing the rectangular-duct correction, would pre-empt the question.
* The 85th-percentile threshold selects brighter, better focused particles. The effect on the depth profile has not been measured (the paper says so in Section 4.3). A threshold sweep is a natural supplementary experiment, and `run_preprocessing(..., percentile=...)` supports it directly.
* The number of source frames behind the 600 patches is not stated.

## 6. Review and anonymity
If the manuscript is still under double-anonymous review, a public repository with author names, affiliations and a CITATION file can reveal identities. Consider keeping the repository private, or using an anonymised mirror, until the review is finished.
