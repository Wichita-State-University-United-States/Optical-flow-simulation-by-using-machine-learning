# Image-processing pipeline (manuscript Section 2.1)

The pipeline turns a raw PSV frame into a list of cropped streak candidates. It is implemented in `psv/preprocessing.py`.

```
raw frame ──► background subtraction ──► contrast enhancement ──► adaptive threshold
                                                                        │
      cropped 224 x 224 patches ◄── contour extraction (area filter) ◄──┘
```

## Noise sources the pipeline targets

| Source | Character | Handled by |
|---|---|---|
| Static background (walls, optics, substrate) | constant in time | averaged background subtraction |
| Camera sensor noise (thermal, dark current) | random per frame | noise-floor term, area filter |
| Specular reflections and diffraction halos | structured, per frame | CNN classifier |
| Out-of-focus particle scatter | smooth, dim, large | percentile threshold, CNN classifier |
| Overlapping streaks | merged contours | CNN classifier (treated as "replaced") |

## Steps

### 1. Background estimation and subtraction
`build_background()` averages N = 50 flow-off reference frames (25 from the start and 25 from the end of the 300-frame sequence). `subtract_background()` subtracts this mean from each frame and clips negative values to zero.

`build_background(..., return_std=True)` also returns the per-pixel standard deviation of the reference stack. If passed to `subtract_background(noise_std=...)`, `k * std` (k = 3) is removed as well. **This noise-floor term is an implementation choice, not stated in the manuscript.** Without it, about half of all pixels remain slightly positive after clipping and the "non-zero percentile" rule in step 3 operates on noise.

### 2. Adaptive contrast enhancement
The manuscript does not name the operator. `enhance_contrast()` offers two options:

* `method="stretch"` (default): linear stretch of the 1st to 99.5th percentile of the non-zero intensities onto 1..255. Zeros stay zero. The stretch adapts to the intensity range of each image, which covers both illumination modes (pulsed, roughly 40 to 220; continuous, roughly 120 to 200).
* `method="clahe"`: OpenCV CLAHE. It lifts zero pixels, which weakens step 3, so it is not the default.

A 3 x 3 Gaussian smoothing is applied first (`SMOOTH_KSIZE`, set 0 to disable). This is also an implementation choice.

### 3. Adaptive (percentile) threshold
`adaptive_threshold()` computes the 85th percentile of the **non-zero** pixel intensities of the enhanced image. Pixels below it are set to 0, pixels at or above it keep their value (Fig. 2 of the paper). No manual re-tuning is needed between lighting modes, because the threshold is derived from each image.

Consequence stated in the manuscript (Section 3 and 4.3): the threshold preferentially keeps brighter, better focused particles, and the in-focus to out-of-focus transition is smooth, so the selection is biased. The effect on the velocity profile has not been quantified.

### 4. Contour-based candidate extraction
`extract_candidates()` runs `cv2.findContours` (external contours) on the thresholded image, discards contours with area below `MIN_CONTOUR_AREA` (40 px, assumed), and records the bounding box and a filled mask for each survivor.

### 5. Patch cropping
`crop_patch()` takes a square window around each bounding box (15 % margin), resizes it to 224 x 224 while preserving aspect ratio, and scales intensities to [0, 1]. Bounding-box coordinates are kept so that results can be mapped back to the full frame.

## Reconstruction after classification
`psv/reconstruct.py`: every candidate classified as *retained* keeps its background-subtracted pixels (mask dilated by 2 px); every *replaced* candidate and all unmatched pixels are set to the local background (zero after subtraction). Overlapping streaks form one merged contour and are therefore classified as replaced, as stated in the paper.

## Streak measurements
`psv/velocity.py`:

* orientation and length from the principal axis (SVD) of the candidate mask,
* speed = (L - d) x pixel size / exposure time, with exposure 45 ms and 0.265 um/pixel. The manuscript does not say whether the particle image diameter d (about 75 px) is subtracted, so `particle_diameter_px` defaults to 0,
* vector sign taken from the known bulk-flow direction. The CNN does not decide forward versus backward motion.

## Tunable parameters
All are collected in `psv/config.py`, with each value marked `[paper]` or `[assumed]`.
