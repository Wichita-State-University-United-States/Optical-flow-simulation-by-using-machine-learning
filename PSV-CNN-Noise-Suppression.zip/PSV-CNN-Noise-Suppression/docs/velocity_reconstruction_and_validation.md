# Velocity reconstruction and validation (manuscript Section 4.2)

## Reference solution
Planar Poiseuille flow across the channel depth H = 0.9 mm:

    u(z) = 4 u_max (z/H) (1 - z/H),      u_max = 1.5 u_mean = 2.363 mm/s

Flow parameters: Re = u_mean D_h / nu = 2.4, nu = 1.0e-6 m2/s, D_h = 2WH/(W+H) = 1.525 mm, aspect ratio W/H = 5.56. The Reynolds number uses the bulk mean velocity, not the centreline velocity. Code: `psv.velocity.poiseuille_velocity`.

## Error metric: MVNAE
The maximum-velocity-normalised absolute error at depth position i is

    eps_i = | u_i,PSV - u_i,Poi | / u_max x 100 %

It is **not** a conventional relative error (the denominator is the global maximum, not the local analytical velocity). Near the walls, where the local velocity is small, MVNAE therefore looks much smaller than a local relative error would. Code: `psv.velocity.mvnae`. The earlier "97.3 % accuracy" statement was removed from the manuscript and should not be derived as 100 minus the mean error.

## Reported result (20 depth positions)

| Statistic | Value |
|---|---|
| Mean MVNAE | 2.64 % |
| RMS error | 3.19 % |
| Maximum pointwise error | 7.28 % (z/H = 0.860) |
| Positions with MVNAE at or below 5 % | 19 of 20 |

The full table is in `data/reported/table1_velocity_profile.csv`. `scripts/05_reproduce_reported_results.py` recomputes the Poiseuille column and the MVNAE column and the summary statistics; the maximum difference from the printed values is 0.04 percentage points (rounding of u_max, 2.36 versus 2.363). From the two-decimal table alone the mean comes out as 2.63 to 2.64 and the RMS as 3.19 to 3.20; the paper's 2.64 and 3.19 were computed from unrounded velocities, which is why the regenerated figure prints the quoted values.

## Baseline comparison (Table 2 of the paper)
Stored in `data/reported/table2_method_comparison.csv`. F1 values come from the independent 300-patch test set; mean MVNAE comes from the 20-position profile obtained with each complete processing route. They are related but separate evaluations and are not measured on the same samples. Processing time (148 ms per frame for the full pipeline) was measured on an Intel Core i7-9700K with 32 GB RAM, Python 3.9 and TensorFlow 2.8, CNN inference on CPU, averaged over 100 frames, excluding training.

## Applying the code to your own frames
1. Build the background and noise floor from flow-off frames: `P.build_background(refs, return_std=True)`.
2. `P.run_preprocessing(frame, B, SD)` returns candidates and all intermediate images.
3. `classify_candidates(model, candidates)` then `reconstruct(...)`.
4. `streak_geometry(mask)` gives length and orientation; `streak_speed_mms(...)` converts length to speed; `signed_vector(...)` applies the bulk-flow direction.
5. Group speeds by depth position and compare with `poiseuille_velocity` using `mvnae` and `error_summary`.

How a depth position z is assigned to each measured streak is not described in the manuscript, so that step is intentionally left to the user.

## Synthetic end-to-end check (this repository)
`scripts/04_denoise_and_measure_demo.py` runs the whole chain on 20 unseen synthetic frames, where ground truth is known. See `results/demo_synthetic/end_to_end_metrics.json`. It shows that the percentile threshold shortens measured streaks slightly (negative length bias), which is the kind of threshold effect discussed in Section 4.3 of the paper.
