# CNN classifier and training protocol (manuscript Sections 2.2 and 2.3)

## Task
Binary classification of pre-extracted streak candidates: class 0 = **replaced** (artifact, background, overlap), class 1 = **retained** (valid streak). The CNN is the last discriminative stage; background averaging, thresholding and area filtering do the main noise suppression before it.

## Architecture (`psv/model.py`)

| Stage | Output shape |
|---|---|
| Input (grayscale patch) | 224 x 224 x 1 |
| Conv 3x3, 32, ReLU + MaxPool 2x2 | 112 x 112 x 32 |
| Conv 3x3, 64, ReLU + MaxPool 2x2 | 56 x 56 x 64 |
| Conv 3x3, 128, ReLU + MaxPool 2x2 | 28 x 28 x 128 |
| Conv 3x3, 256, ReLU + MaxPool 2x2 | 14 x 14 x 256 |
| Conv 3x3, 256, ReLU + MaxPool 2x2 | 7 x 7 x 256 |
| Flatten | 12,544 |
| Dense 1024, ReLU, Dropout 0.5 | 1024 |
| Dense 256, ReLU, Dropout 0.5 | 256 |
| Dense 2, Softmax | 2 |

All convolutions use stride 1 and zero padding of one pixel ("same"). Total trainable parameters: **14,086,914**. `python -m psv.model` prints the summary and asserts the 12,544 flatten size.

The network is a conventional CNN. It has no PSV-specific directional kernels or explicit aspect-ratio descriptors, and it is not a reproduction of LeNet-5.

## Optimisation
Adam, learning rate 0.001, beta1 = 0.9, beta2 = 0.999, sparse categorical cross-entropy, normal weight initialisation (standard deviation not given in the paper; 0.02 used here), 100 epochs. Batch size is not stated (16 used here).

## Dataset protocol
* 600 labelled 224 x 224 grayscale patches: 300 retained, 300 replaced.
* Stratified 50:50 split **at the level of source frames** (300 train, 300 test, 150 per class in each). All patches from one frame stay in the same subset.
* A validation subset is held out of the training pool, also by source frame, for monitoring convergence.
* Augmentation on the training set only: rotation up to +/-30 degrees, horizontal and vertical flips, scaling by +/-10 percent, then crop or pad to the original size (`psv/augment.py`). Labels do not depend on physical flow direction, so these transforms preserve them.
* The test set is not augmented and is not used for training or hyperparameter tuning.

## Metrics
Retained class is the positive class. Reported on the 300-patch test set (Fig. 7): TN = 150, FP = 0, FN = 1, TP = 149, giving accuracy 0.997, precision 1.000, recall 0.993, F1 0.997. `scripts/05_reproduce_reported_results.py` recomputes these from the matrix.

## What is and is not in this repository
The 600 real labelled patches and the trained weights from the paper are **not** included. `scripts/01` to `03` build and train on a synthetic stand-in dataset so that the full code path can be run and checked. See `reproducibility_notes.md`.
