#!/usr/bin/env bash
# Full synthetic demo: dataset -> training -> evaluation -> end-to-end -> reported-results checks.
# Training for 25 epochs takes roughly 10 minutes on one CPU core.
set -euo pipefail
EPOCHS=${1:-25}
python scripts/01_generate_synthetic_dataset.py
python scripts/02_train_cnn.py --epochs "$EPOCHS"
python scripts/03_evaluate_cnn.py
python scripts/04_denoise_and_measure_demo.py
python scripts/05_reproduce_reported_results.py
echo "Done. See results/"
