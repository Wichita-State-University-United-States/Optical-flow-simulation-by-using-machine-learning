"""Fast unit tests (no training): run with  pytest -q"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import numpy as np
from psv import config as C, preprocessing as P, velocity as V, metrics as M, synthetic as S


def test_flow_parameters_consistent():
    assert abs(V.hydraulic_diameter() - 1.525) < 1e-3
    assert abs(V.reynolds(C.U_MEAN_MMS) - 2.4) < 0.01
    assert abs(C.U_MAX_MMS - 2.3625) < 1e-9


def test_poiseuille_symmetry_and_peak():
    z = np.array([0.0, 0.45, 0.9])
    u = V.poiseuille_velocity(z)
    assert u[0] == 0 and u[2] == 0 and abs(u[1] - C.U_MAX_MMS) < 1e-9


def test_mvnae_definition():
    assert abs(V.mvnae(2.0, 1.0, 2.0) - 50.0) < 1e-12


def test_confusion_metrics_match_manuscript():
    y = [0] * 150 + [1] * 150
    p = [0] * 151 + [1] * 149
    m = M.classification_metrics(y, p)
    assert m["accuracy"] == 0.9967 and m["precision"] == 1.0
    assert abs(m["recall"] - 0.9933) < 1e-4 and abs(m["f1_retained"] - 0.9967) < 1e-4


def test_percentile_threshold_uses_nonzero_pixels_only():
    img = np.zeros((50, 50), np.uint8)
    img[10:20, 10:20] = np.arange(1, 101).reshape(10, 10)
    out, thr = P.adaptive_threshold(img, 85.0)
    assert abs(thr - np.percentile(np.arange(1, 101), 85)) < 1e-6
    assert (out[img < thr] == 0).all()


def test_pipeline_finds_streak_and_rejects_nothing_spurious():
    rng = np.random.default_rng(0)
    bg = S.make_static_background((200, 300), rng)
    refs = [S.make_frame(bg, rng, with_streaks=False, with_artifacts=False)[0] for _ in range(20)]
    B, SD = P.build_background(refs, return_std=True)
    frame, truth = S.make_frame(bg, rng, n_streaks=6)
    out = P.run_preprocessing(frame, B, SD)
    assert len(out["candidates"]) >= 1
    assert out["candidates"][0].patch.shape == (224, 224)


def test_streak_geometry_horizontal_line():
    m = np.zeros((40, 100), bool); m[20, 10:70] = True
    L, ang, _ = V.streak_geometry(m)
    assert abs(L - 60) < 1.5 and abs(ang) < 1.0


def test_signed_vector_follows_flow_direction():
    v = V.signed_vector(170.0 - 180.0, 1.0, (1, 0))      # axis pointing left -> flipped
    assert v[0] > 0
